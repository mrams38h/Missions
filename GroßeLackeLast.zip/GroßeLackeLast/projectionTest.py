import numpy as np
from pyproj import Proj, transform
from operator import itemgetter

inProj = Proj('epsg:25833')
outProj = Proj('epsg:4326')
x1,y1 = 629027.7202947022,5288318.432230721
x2,y2 = transform(inProj,outProj,x1,y1)
print(x2,y2)


buffer = [[0,0,0,0,0,0,0]]



b1 = [10,12,8,5,1,5,9]
b2 = [0,8,12,6,3,8,23]
b3 = [3,79,6,6,0,12,85]

buffer.append(b1)
buffer.append(b2)
buffer.append(b3)



#print(buffer)

sortedBuffer = sorted(buffer, key=itemgetter(0), reverse=False)

#print(sortedBuffer)


for line in sortedBuffer:
    print(str(line[0])+"-"+str(line[1]))
    
